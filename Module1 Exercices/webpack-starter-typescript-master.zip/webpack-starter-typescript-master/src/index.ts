


const mensaje = 'Hola Mundo!';

console.log( mensaje );